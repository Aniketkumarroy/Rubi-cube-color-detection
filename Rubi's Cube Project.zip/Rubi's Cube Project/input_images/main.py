import cv2 as cv
import numpy as np
index=int(input("enter index:"))
path="image{}.jpg".format(index)
img=cv.imread(path)
blank=np.zeros(img.shape,np.uint8)
blank2=blank.copy()#ghdkyj
# img_blur=cv.bilateralFilter(img,15,75,75)
# img_blur=cv.medianBlur(img,7)
#------------------------------------------------
img_gray=cv.cvtColor(img,cv.COLOR_BGR2GRAY)
img_blur=cv.GaussianBlur(img_gray,(7,7),None)
img_erode=cv.erode(img_blur,(7,7),iterations=3)
img_dilate=cv.dilate(img_erode,(7,7),iterations=3)
img_canny=cv.Canny(img_dilate,80,120)
#------------------------------------------------
conts,hier=cv.findContours(img_canny,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)


# cv.drawContours(blank,conts,-1,(255,255,255),1)


max_contour=max(conts,key=cv.contourArea)
cv.drawContours(blank2,max_contour,-1,(255,255,255),1)
peri=cv.arcLength(max_contour,True)
pnt=cv.approxPolyDP(max_contour,0.04*peri,True)
cv.fillPoly(blank,[pnt],(255,255,255))
# cv.polylines(blank,[pnt],True,(255,255,255),1)
# cv.rectangle(blank,(int(pnt[0]),int(pnt[1])),(int(pnt[0]+pnt[2]),int(pnt[1]+pnt[3])),(255,255,255),-1)
img_cube=cv.bitwise_and(img,blank)

print(len(max_contour))
print(pnt)
print(len(pnt))
print(img.shape)


cv.imshow("1",img)
cv.imshow("1_blur",img_blur)
cv.imshow("1_gray",img_gray)
cv.imshow("1_erode",img_erode)
cv.imshow("1_dilate",img_dilate)
cv.imshow("1_mask",blank)
cv.imshow("1_max",blank2)
cv.imshow("1_cube",img_cube)
cv.waitKey(0)
cv.destroyAllWindows()
print("ok")