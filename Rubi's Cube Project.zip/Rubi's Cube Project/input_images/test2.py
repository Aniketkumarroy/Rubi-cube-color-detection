import cv2 as cv
import numpy as np


img=cv.imread("image8.jpg")
blank=np.zeros(img.shape,np.uint8)
out=blank.copy()

# gray=cv.cvtColor(img,cv.COLOR_BGR2GRAY)
img_blur=cv.GaussianBlur(img,(7,7),0)
img_filter=cv.bilateralFilter(img_blur,15,75,75)
img_denoise = cv.fastNlMeansDenoisingColored(img_filter, None, 5, 10, 7, 21)
img_gray=cv.cvtColor(img_denoise,cv.COLOR_BGR2GRAY)
thresh=cv.adaptiveThreshold(img_gray,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,cv.THRESH_BINARY,21,5)
img_out=cv.bitwise_and(img_denoise,img_denoise,mask=thresh)
img_canny=cv.Canny(img_out,20,150)
img_dilate=cv.dilate(img_canny,(7,7))
conts,hier=cv.findContours(img_canny,cv.RETR_TREE,cv.CHAIN_APPROX_SIMPLE)

# ret,thresh2=cv.threshold(gray,20,255,cv.THRESH_BINARY)

for cnts in conts:
    peri=cv.arcLength(cnts,True)
    approx=cv.approxPolyDP(cnts,0.04*peri,True)
    if len(approx)==4:
        cv.fillPoly(blank,[approx],(255,255,255))



cv.imshow("img_denoise",img_denoise)
cv.imshow("img",img)
cv.imshow("img_blur",img_blur)
cv.imshow("img_filter",img_filter)
cv.imshow("img_canny",img_canny)
cv.imshow("img_dilate",img_dilate)
cv.imshow("output",blank)
cv.imshow("gray",img_gray)
cv.imshow("thresh",thresh)
cv.imshow("img_out",img_out)
cv.waitKey(0)
cv.destroyAllWindows()