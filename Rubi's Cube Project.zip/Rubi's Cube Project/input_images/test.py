import cv2 as cv
import numpy as np
img=cv.imread("image5.jpg")
blank=np.zeros(img.shape,np.uint8)
img_filter=cv.bilateralFilter(img,20,100,100)
img_canny=cv.Canny(img_filter,20,120)
conts,hier=cv.findContours(img_canny,cv.RETR_TREE,cv.CHAIN_APPROX_NONE)
cv.imshow("img",img)
cv.imshow("img_filter",img_filter)
cv.imshow("img_canny",img_canny)
for cnt in conts:
    cv.drawContours(blank,cnt,-1,(255,255,255),1)
    cv.imshow("blank",blank)
    cv.waitKey(500)
cv.destroyAllWindows()