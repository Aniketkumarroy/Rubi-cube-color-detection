import cv2 as cv
import numpy as np
from skimage.util import random_noise
# img=cv.imread("C:\\Users\\ANIKET KUMAR ROY\\Desktop\\Programming\\scenary2.jpeg")
# cv.imshow("scenary",img)
# def trans(img,x,y,scale=1.0):
#     transmat=np.float32([[1,0,x],[0,1,y]])
#     dim=(img.shape[1],img.shape[0])
#     return cv.warpAffine(img,transmat,dim,scale)
# def rotate(img,angle,rotpoint=None,scale=1):
#     if rotpoint is None:
#         rotpoint=(img.shape[1]//2,img.shape[0]//2)
#     dim=(img.shape[1],img.shape[0])
#     mat=cv.getRotationMatrix2D(rotpoint,angle,scale)
#     return cv.warpAffine(img,mat,dim)
# hori_flip=cv.flip(img,1)
# ver_flip=cv.flip(img,0)
# cv.imshow("translated",trans(img,100,0))
# cv.imshow("rotated",rotate(img,100,None,2))
# cv.imshow("horizontal flip",hori_flip)
# cv.imshow("vertical flip",ver_flip)
# print("ok")

# img = cv.imread("image4.jpg")
 
# # Add salt-and-pepper noise to the image.
# noise_img = random_noise(img, mode='s&p',amount=0.3)
 
# # The above function returns a floating-point image
# # on the range [0, 1], thus we changed it to 'uint8'
# # and from [0,255]
# noise_img = np.array(255*noise_img, dtype = 'uint8')
 
# # Display the noise image
# cv.imshow('blur',noise_img)
# cv.imwrite("image5.jpg",noise_img)
# cv.waitKey(0)
# cv.destroyAllWindows()

import cv2 as cv
import numpy as np
path="C:\\Users\\ANIKET KUMAR ROY\\Desktop\\Rubi's Cube Project\\image3.jpg"
cv.namedWindow("trackbar")
cv.resizeWindow("trackbar",640,240)
def empty(x):
    pass
cv.createTrackbar("hue min","trackbar",0,179,empty)
cv.createTrackbar("hue max","trackbar",179,179,empty)
cv.createTrackbar("sat min","trackbar",109,255,empty)
cv.createTrackbar("sat max","trackbar",255,255,empty)
cv.createTrackbar("val min","trackbar",187,255,empty)
cv.createTrackbar("val max","trackbar",255,255,empty)
while True:
    img=cv.imread(path)
    imghsv=cv.cvtColor(img,cv.COLOR_BGR2HSV)
    h_min=cv.getTrackbarPos("hue min","trackbar")
    h_max=cv.getTrackbarPos("hue max","trackbar")
    sat_min=cv.getTrackbarPos("sat min","trackbar")
    sat_max=cv.getTrackbarPos("sat max","trackbar")
    val_min=cv.getTrackbarPos("val min","trackbar")
    val_max=cv.getTrackbarPos("val max","trackbar")
    cv.imshow("original",img)
    cv.imshow("hsv",imghsv)
    lower=np.array([h_min,sat_min,val_min])
    upper=np.array([h_max,sat_max,val_max])
    mask=cv.inRange(imghsv,lower,upper)
    cv.imshow("mask",mask)
    output=cv.bitwise_and(img,img,mask=mask)
    cv.imshow("output",output)
    if cv.waitKey(10)&0xFF==ord('d'):
        break
print("ok")
cv.destroyAllWindows()