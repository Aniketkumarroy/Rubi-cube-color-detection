import cv2 as cv
import numpy as np
path="C:\\Users\ANIKET KUMAR ROY\\Desktop\\Programming\\OpenCV-files\\rubicube.png"
img=cv.imread(path)
img2=img.copy()
v=[96,165,109,255,143,255,46,82,109,255,130,255,0,0,80,255,255,255,0,0,0,0,255,255,10,23,68,255,243,255,25,40,109,255,130,255]
c=["B","G","R","W","O","Y"]
for i in range(0,31,6):
    imghsv=cv.cvtColor(img,cv.COLOR_BGR2HSV)
    lower=np.array([v[i],v[i+2],v[i+4]])
    upper=np.array([v[i+1],v[i+3],v[i+5]])
    mask=cv.inRange(imghsv,lower,upper)
    output=cv.bitwise_and(img,img,mask=mask)
    output_gray=cv.cvtColor(output,cv.COLOR_BGR2GRAY)
    cont,hier=cv.findContours(output_gray,cv.RETR_LIST,cv.CHAIN_APPROX_NONE)
    for cnt in cont:
        peri=cv.arcLength(cnt,True)
        approx=cv.approxPolyDP(cnt,0.02*peri,True)
        cv.putText(img2,c[i//6],((approx[0][0][0]+approx[2][0][0])//2-10,(approx[0][0][1]+approx[2][0][1])//2+10),cv.FONT_HERSHEY_TRIPLEX,1,(0,0,0),1)
    cv.imshow("original",img)
    cv.imshow("mask",mask)
    cv.imshow("output",output)
    cv.imshow("done",img2)
    if cv.waitKey(1000)&0xFF==ord('d'):
        break
print("ok")
cv.destroyAllWindows()